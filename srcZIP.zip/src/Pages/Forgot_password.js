import Forgotpw from '../Components/Forgotpw'


export default function Forgot_password(){

    return(
        <>
        
        <Forgotpw />
       
        
        </>
    )
}