import Login from '../Components/Login'


export default function Log(){

    return(
        <>
        
        <Login />
        
        
        </>
    )

}