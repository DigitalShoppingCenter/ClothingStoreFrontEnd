import React from "react";

export default function ComingSoon(){

    return(
        <h2 style= {{

        textAlign: 'center', 
        position: "relative", 
        top: "150px", 
        border: "solid",
        padding: "15px", 
        width: "700px", 
        left: "300px"
    }}>
            Work is still on progress... Thank you for waiting :)</h2>
    )

}