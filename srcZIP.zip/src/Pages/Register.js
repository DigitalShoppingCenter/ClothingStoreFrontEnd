import Regist from '../Components/Regist'



export default function Register(){

    return(
        <>
        
        <Regist />
        
     
        </>
    )
}