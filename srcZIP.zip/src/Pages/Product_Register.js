import Addproduct from '../Components/Addproduct'



export default function Product_Register() {


    return(
        <>
            <Addproduct />
            
            </>
    )
}

   
    