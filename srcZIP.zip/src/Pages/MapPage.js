import Navbar from '../Components/Navbar'
import Map from '../Components/MyMap'


export default function MapPage(){

    return(
        <>
        
        <Navbar /><br></br>
        <Map />
        </>
    )
}