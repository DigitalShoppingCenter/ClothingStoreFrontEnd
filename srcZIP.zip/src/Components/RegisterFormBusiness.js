import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../Styling/registerbusiness.css';
import { jwtDecode } from 'jwt-decode';
import Navbar from '../Components/Navbar';

const RegisterBusinessForm = () => {
    const [businessData, setBusinessData] = useState({
        name: '',
        description: ''
    });
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleChange = (e) => {
        setBusinessData({ ...businessData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        // Retrieve token from localStorage
        const tokenData = localStorage.getItem('token');
        if (!tokenData) {
            setError("You must be logged in to create a business.");
            return;
        }

        try {
            // Parse the stored token data
            const parsedTokenData = JSON.parse(tokenData);
            const token = parsedTokenData.token || parsedTokenData;

            if (!token) {
                setError("Invalid authentication data.");
                return;
            }

            // Decode JWT token and extract role from correct key
            const decodedToken = jwtDecode(token);
            console.log("Decoded Token:", decodedToken);

            // Extract role properly from claims
            const roleKey = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
            const userRole = decodedToken[roleKey];  // Fix: Extract role from claims

            console.log("User Role:", userRole);

            if (!userRole || userRole !== "Owner") {
                setError("You are not authorized to create a business.");
                return;
            }

            // Ensure UserId is included in the request
            const userId = decodedToken.UserId || decodedToken.userId;
            if (!userId) {
                setError("Invalid user data.");
                return;
            }

            // Make API request to create a business
            const response = await fetch('https://urchin-app-lpasr.ondigitalocean.app/api/business', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    name: businessData.name,
                    description: businessData.description,
                    ownerId: userId // Required by backend
                })
            });

            console.log("API Response:", response);

            if (!response.ok) {
                const errorText = await response.text();
                console.error("Error creating shop:", errorText);
                throw new Error(`Failed to create shop: ${errorText}`);
            }

            const data = await response.json();
            console.log("Business Created:", data);
            navigate(`/shops/${data.businessId}`);
        } catch (error) {
            console.error('Error creating shop:', error);
            setError(error.message);
        }
    };

    return (
        <div>
            <Navbar />
            <div className="register-business-form-container">
                <h2>Create Your Shop</h2>
                <form onSubmit={handleSubmit} className="register-business-form">
                    <input
                        type="text"
                        name="name"
                        placeholder="Shop Name"
                        value={businessData.name}
                        onChange={handleChange}
                        required
                    />
                    <textarea
                        name="description"
                        placeholder="Shop Description"
                        value={businessData.description}
                        onChange={handleChange}
                        required
                    ></textarea>
                    
                    <button type="submit" className="submit-button">
                        Create Shop
                    </button>
                    {error && <p className="error-message">{error}</p>}
                </form>
            </div>
        </div>
    );
};

export default RegisterBusinessForm;
