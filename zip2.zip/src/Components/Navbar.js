import React, { useState, useEffect, useContext } from 'react';
import '../Styling/navbar.css';
import { verifyToken } from '../Mock_DataBase/Generate_Token';
import { FaUser } from "react-icons/fa";
import { useTheme } from '../Components/ThemeContext'

const Navbar = () => {
  const { isDarkMode, toggleTheme } = useTheme();
  const [loggedUser, setLoggedUser] = useState(null);
  const [isDropdownVisible, setDropdownVisible] = useState(false);

  const toggleDropdown = () => {
    setDropdownVisible(prevVisible => !prevVisible);
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      const userData = verifyToken(token);
      setLoggedUser(userData);
    }
  }, []);

  const handleLogout = () => {
    localStorage.clear("token");
    window.location.href = "http://localhost:3000/";
  };

  return (
    <div className='navbar_container'>
      <nav className="navbar">
        <div className="logo-container">
          <a href='http://localhost:3000'>
            <img src={`${process.env.PUBLIC_URL}/Assets/edlogo.png`} id='edlogo' alt="E & D Corporation Logo" />
          </a>
          <h3 id='edcorp'>E & D Corporation</h3>
        </div>

        <input type="checkbox" id="toggle-menu" className="toggle-menu" />
        <label htmlFor="toggle-menu" className="hamburger">
          <span className="bar"></span>
          <span className="bar"></span>
          <span className="bar"></span>
        </label>

        <ul className="nav-links">
          <label htmlFor="toggle-menu" className="close-btn">X</label>
          <li><a href="http://localhost:3000">Home</a></li>
          <li><a href="http://localhost:3000/shops">Shops</a></li>
          <li><a href="">About</a></li>
          <li><a href="">Contact</a></li>
          <button onClick={toggleTheme} style={{ marginRight: "10px" }}>
            {isDarkMode ? "Light Mode" : "Dark Mode"}
          </button>
          {loggedUser ? (
            <li id="welcome_logged_user" className="user-menu">
              <span className="welcome-text">
                <FaUser style={{ marginTop: "1px", marginRight: "2px" }}/>
                {loggedUser.username}
              </span>
              <button onClick={toggleDropdown} className="dropdown-toggle">▼</button>
              {isDropdownVisible && (
                <div className="dropdown-menu">
                  <button className='edit_profile'><a href='http://localhost:3000/user_update'>Edit Profile</a></button>
                  <button onClick={handleLogout} className="logout-button">Logout</button>
                </div>
              )}
            </li>
          ) : (
            <div className="auth-buttons">
              <button id='log_login'><a href='http://localhost:3000/login'>Login</a></button>
              <button id='log_regist_edit'><a href='http://localhost:3000/register'>Register</a></button>
            </div>
          )}
        </ul>
      </nav>
    </div>
  );
};

export default Navbar;
